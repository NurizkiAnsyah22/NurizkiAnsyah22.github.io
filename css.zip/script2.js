// Event pada saat link di klik
$('.page-scroll').on('click', function (e) {
    var tujuan = $(this).attr('href');
    var elementTujuan = $(tujuan);

    // Pindahkan scroll
    $('html, body').animate({
        scrollTop: elementTujuan.offset().top - 50
    }, 1300, 'easeInOutCubic');

    e.preventDefault();
});

// Efek ketik pada teks "Nurizkiansyah" dan "Web Developer | Software Engineer"
$(document).ready(function() {
    var h1Element = $('.jumbotron h1');
    var pElement = $('.jumbotron p');

    h1Element.hide();
    pElement.hide();

    setTimeout(function() {
        h1Element.show().addClass('typing');
        typeEffect(h1Element, h1Element.text(), 0);
    }, 1000);

    setTimeout(function() {
        pElement.show().addClass('typing');
        typeEffect(pElement, pElement.text(), 0);
    }, 1500);

    function typeEffect(element, text, index) {
        if (index < text.length) {
            element.text(text.slice(0, index + 1));
            index++;
            setTimeout(function() {
                typeEffect(element, text, index);
            }, 100);
        } else {
            element.removeClass('typing');
        }
    }
});

// Untuk menyimpan parallax
$(window).scroll(function() {
    var wScroll = $(this).scrollTop();

    $('.jumbotron img').css({
        'transform': 'translate(0px, ' + wScroll/3 + '%)'
    });

    $('.jumbotron h1').css({
        'transform': 'translate(0px, ' + wScroll/2 + '%)'
    });

    $('.jumbotron p').css({
        'transform': 'translate(0px, ' + wScroll/1.5 + '%)'
    });

    // Tambahkan efek zoom saat scroll
    if (wScroll > 0) {
        $('.jumbotron').addClass('zoomed');
    } else {
        $('.jumbotron').removeClass('zoomed');
    }
});

// Atur nilai background-size secara bertahap saat scroll
var scrollTimeout;
$(window).scroll(function() {
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(function() {
        var wScroll = $(window).scrollTop();
        var zoomLevel = wScroll / 1000 + 1;

        $('.jumbotron').css({
            'background-size': zoomLevel * 100 + '% auto'
        });
    }, 20);
});
